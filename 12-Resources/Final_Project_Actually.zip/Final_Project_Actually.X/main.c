#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/system/pins.h"
#include "mcc_generated_files/uart/uart1.h"
#include "mcc_generated_files/i2c_host/i2c1.h"
#include <stdint.h>
#include <stdbool.h>

#define MY_ID 'F'
#define HUMIDITY_DEST 'W'
#define BROADCAST_ID 'X'   // <-- MATCH ESP32

#define FRAME_SIZE 64      // ? FIXED
#define MSG_START 4

#define SENSOR_SEND_INTERVAL_MS 5000
#define MAIN_LOOP_DELAY_MS 10

#define SHTC3_ADDR 0x70
#define CMD_WAKE_MSB   0x35
#define CMD_WAKE_LSB   0x17
#define CMD_SLEEP_MSB  0xB0
#define CMD_SLEEP_LSB  0x98
#define CMD_MEAS_MSB   0x78
#define CMD_MEAS_LSB   0x66

static uint8_t rxBuffer[FRAME_SIZE];
static uint8_t rxIndex = 0;

// ================= UART =================

static void UART_SendByte_Blocking(uint8_t b)
{
    while (!UART1_IsTxReady()) {}
    UART1_Write(b);
}

static void UART_SendBuffer(const uint8_t *data, uint8_t len)
{
    for (uint8_t i = 0; i < len; i++)
    {
        UART_SendByte_Blocking(data[i]);
    }
}

// ================= Packet =================

static bool IsKnownID(uint8_t id)
{
    return (id == 'B' || id == 'F' || id == 'W' ||
            id == 'T' || id == 'H' || id == 'X');
}

static void BuildFrame(uint8_t dst, const char *msg, uint8_t *frame)
{
    // Clear full frame
    for (uint8_t i = 0; i < FRAME_SIZE; i++)
    {
        frame[i] = 0x00;
    }

    frame[0] = 'A';
    frame[1] = 'Z';
    frame[2] = MY_ID;
    frame[3] = dst;

    // Copy message
    for (uint8_t i = 0; i < (FRAME_SIZE - 6) && msg[i] != '\0'; i++)
    {
        frame[MSG_START + i] = (uint8_t)msg[i];
    }

    frame[62] = 'B';
    frame[63] = 'Y';
}

static void SendPacketText(uint8_t dst, const char *msg)
{
    uint8_t frame[FRAME_SIZE];
    BuildFrame(dst, msg, frame);
    UART_SendBuffer(frame, FRAME_SIZE);
}

static void SendHumidity(uint8_t h)
{
    char msg[5];

    if (h > 100)
    {
        h = 100;
    }

    msg[0] = 'H';
    msg[1] = (char)('0' + (h / 100));
    msg[2] = (char)('0' + ((h / 10) % 10));
    msg[3] = (char)('0' + (h % 10));
    msg[4] = '\0';

    SendPacketText(HUMIDITY_DEST, msg);
}

// ================= SHTC3 =================

static bool I2C_WaitDone(void)
{
    uint32_t timeout = 60000;

    while (I2C1_IsBusy() && timeout > 0)
    {
        timeout--;
    }

    return (timeout > 0);
}

static bool SHTC3_WriteCommand(uint8_t msb, uint8_t lsb)
{
    uint8_t cmd[2] = {msb, lsb};

    if (!I2C1_Write(SHTC3_ADDR, cmd, 2)) return false;
    if (!I2C_WaitDone()) return false;

    return (I2C1_ErrorGet() == I2C_ERROR_NONE);
}

static uint8_t SHTC3_CalcCRC(const uint8_t *data, uint8_t len)
{
    uint8_t crc = 0xFF;

    for (uint8_t i = 0; i < len; i++)
    {
        crc ^= data[i];

        for (uint8_t bit = 0; bit < 8; bit++)
        {
            if (crc & 0x80)
                crc = (uint8_t)((crc << 1) ^ 0x31);
            else
                crc <<= 1;
        }
    }

    return crc;
}

static bool ReadHumidity(uint8_t *humidity)
{
    uint8_t rx[6];

    if (!SHTC3_WriteCommand(CMD_WAKE_MSB, CMD_WAKE_LSB)) return false;
    __delay_ms(1);

    if (!SHTC3_WriteCommand(CMD_MEAS_MSB, CMD_MEAS_LSB)) return false;
    __delay_ms(20);

    if (!I2C1_Read(SHTC3_ADDR, rx, 6)) return false;
    if (!I2C_WaitDone()) return false;
    if (I2C1_ErrorGet() != I2C_ERROR_NONE) return false;

    (void)SHTC3_WriteCommand(CMD_SLEEP_MSB, CMD_SLEEP_LSB);

    if (SHTC3_CalcCRC(&rx[0], 2) != rx[2]) return false;
    if (SHTC3_CalcCRC(&rx[3], 2) != rx[5]) return false;

    uint16_t rawHumidity = ((uint16_t)rx[3] << 8) | rx[4];
    uint32_t calc = ((uint32_t)100U * rawHumidity + 32767U) / 65535U;

    if (calc > 100U)
    {
        calc = 100U;
    }

    *humidity = (uint8_t)calc;
    return true;
}

// ================= Receive / Forward =================

static void HandlePacket(uint8_t len)
{
    uint8_t src = rxBuffer[2];
    uint8_t dst = rxBuffer[3];

    if (!IsKnownID(src)) return;
    if (src == MY_ID) return;

    if (dst == MY_ID || dst == BROADCAST_ID)
    {
        IO_RA4_SetHigh();
        return;
    }

    if (IsKnownID(dst))
    {
        UART_SendBuffer(rxBuffer, FRAME_SIZE); // ? always send full frame
    }
}

static void ProcessUART(void)
{
    while (UART1_IsRxReady())
    {
        uint8_t b = UART1_Read();

        if (rxIndex == 0)
        {
            if (b == 'A')
            {
                rxBuffer[rxIndex++] = b;
            }
            continue;
        }

        if (rxIndex == 1)
        {
            if (b == 'Z')
            {
                rxBuffer[rxIndex++] = b;
            }
            else
            {
                rxIndex = 0;
            }
            continue;
        }

        if (rxIndex < FRAME_SIZE)
        {
            rxBuffer[rxIndex++] = b;
        }
        else
        {
            rxIndex = 0;
            continue;
        }

        if (rxIndex >= FRAME_SIZE &&
            rxBuffer[62] == 'B' &&
            rxBuffer[63] == 'Y')
        {
            HandlePacket(FRAME_SIZE);
            rxIndex = 0;
        }
    }
}

// ================= Main =================

int main(void)
{
    SYSTEM_Initialize();

    UART1_Enable();
    UART1_TransmitEnable();
    UART1_ReceiveEnable();

    INTERRUPT_GlobalInterruptEnable();

    IO_RA4_SetLow();

    uint16_t sensorTimerMs = 0;

    while (1)
    {
        ProcessUART();

        sensorTimerMs += MAIN_LOOP_DELAY_MS;

        if (sensorTimerMs >= SENSOR_SEND_INTERVAL_MS)
        {
            uint8_t h = 0;

            if (ReadHumidity(&h))
            {
                SendHumidity(h);
                IO_RA4_SetHigh();
            }
            else
            {
                SendPacketText(HUMIDITY_DEST, "SFAIL");
            }

            sensorTimerMs = 0;
        }

        __delay_ms(MAIN_LOOP_DELAY_MS);
    }
}